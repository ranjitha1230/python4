class Car:

    #obj = car() - creating an object - init function is called by default
    #__init__()- assign values to the object properties

    def __init__(self, model , speed):

        self.speed = speed
        self.model = model
        print("I am the first function called in the class")


obj = Car("Honda", 9000)
print(obj.speed)
print(obj.model)



