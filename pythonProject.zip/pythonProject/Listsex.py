# lists are used to store multiple items in a single variable
# lists are stored in square brace
#  access the list items using index concept
# lists are ordered
# allow duplicates
# lists allows different data types.

thislist = ["apple","banana","cherry"]
print(thislist)

# access a particular element in the list
thislist = ["apple","banana","cherry"]
print(thislist[1])

thislist = ["pomogranate","apple","orange","banana","cherry"]
print(thislist)


thislist = ["pomogranate","apple","orange","banana","cherry", "apple" , "banana"]
print(thislist)

thislist = ["pomogranate","apple","orange","banana","cherry", "apple" , "banana"]
print(len(thislist))

thislist = ["pomogranate","123","67.898",False,"cherry677"]
print(thislist)
