class Employee:
    def __init__(self, name , sal):
        # private data members
        self._name = name
        self._sal = sal

    # public methods to acess the above provate data

    def show(self):
        print("Name:" , self._name)
        print("Salary:", self._sal)

# create the object of the class

emp = Employee('Ravi', 40000)
emp.show()

