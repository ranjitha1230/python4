if (5>2):
   print("5 is greater than 2")



