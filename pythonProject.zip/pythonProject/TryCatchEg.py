try:
    print(x)
except NameError:
    print("variable x is not defined")
except:
    print("something went wrong")

# else used to define a block of code to be executed in non errors were raised


try:
    print("Hello")
except:
    print("something went wrong")
else:
    print("nothing went wrong")
finally:
    print("Close the browser")

# custom execpetions - define the exceptions based on the requirememt using raise keyword if the condition occurs

x = -1

if x < 0:
    raise Exception("Sorry , no numbers below zero are allowed")










