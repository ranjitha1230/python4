#age = 36
#txt = "My name is John, I am " + age
#print(txt)


age = 36
txt = "My name is John, I am ",age
print(txt)

age = 36
txt = "My name is John, I am {}"
print(txt.format(age))


quantity = 3
itemno = 658
price = 78.90
myorder = "I want {} peices of item {} for dollars {}"
print(myorder.format(quantity,itemno,price))

quantity = 3
itemno = 658
price = 78.90
myorder = "I want pay {2} dollars for {0} peices of item {1}"
print(myorder.format(quantity,itemno,price))