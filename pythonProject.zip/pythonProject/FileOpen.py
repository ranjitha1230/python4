f = open("C:\\Users\\Harsha Patil\\Documents\\dev\\demofile.txt" , "a")
#print(f.read(17))
#print(f.readline())
#print(f.readline())


#for x in f:
#    print(x)
#f.close()

#read one line read the single line

#for loop for reading the file line by line

# writing to the existing

# a , w

f.write("New learning is added to the training")
f.close()

f = open("C:\\Users\\Harsha Patil\\Documents\\dev\\demofile.txt" , "r")
print(f.read())







