# python casting is converting from one data type to another

x = int("hello world")
print(x)
y = float(3)
print(y)
z = int(2.9)
print(z)
