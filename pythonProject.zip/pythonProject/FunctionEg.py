def func():
    print("This is my first function")


func()

def func_1(a, b):

    c=a+b
    print(c)

func_1(5,4 )
func_1(10,100 )
func_1(200,9 )
func_1(2.3, 7.8)

x = lambda a,b : a * b
print(x(5 ,8))

