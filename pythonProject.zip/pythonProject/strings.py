#index = continuous memory the data stored - starts with 0

a = "Hello world*"
print(a[1])
print(a[5])
print(a[11])

# length of the string

a = "Hello world*"
print(len(a))

#check string - checks if a charcater or a phrase is present in a string - output is in boolean format - true or false

text = "I live in bangalore"
print("luck" in text)


# check If not - to check if the certian phrase ora charatcer is not present in a string

text = "I live in bangalore"
print("mumbai" not in text)

# slicing - this will return a range of characters by using slicing syntax
a = "Hello world*"
print(a[9:11])

# slice from start
# leave the start index

a = "Hello world*"
print(a[:11])

# slice to the end
# leave the end index , and range will go till the end

a = "Hello world*"
print(a[2:])

# modifying

#upper() - capital letters
#lower() - small letters
# strip() - remove spaces
# replace("H","J")
# split string - "Hello,world"

a = "hellowor ld"
print(a.split(" "))

# concatenation  + operator can be used

a = "New"
b = "Delhi"
c = a+" "+b
print(c)

a = 1
b = 2
c = a+b
print(c)











