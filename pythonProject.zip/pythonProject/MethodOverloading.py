class Animal:
    def make_sound(self):
        print("The animal make sound")
