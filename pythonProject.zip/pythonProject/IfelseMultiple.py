letter = "A"

if letter.__eq__("B"):
    print("letter is B")

else:
    if letter.__eq__("C"):
        print("letter is B")

    else:
     if letter.__eq__("A"):
        print("letter is A")

     else:
            print("letter is not A nor B nor C")