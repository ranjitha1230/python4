f = open("C:\\Users\\Harsha Patil\\Documents\\dev\\demofile.txt" , "w")
f.write("New delhi is the capital of india")
f.close()

f = open("C:\\Users\\Harsha Patil\\Documents\\dev\\demofile.txt" , "r")
print(f.read())

f = open("C:\\Users\\Harsha Patil\\Documents\\dev\\file2.txt" , "x")

import os
os.remove("C:\\Users\\Harsha Patil\\Documents\\dev\\file1.txt")
