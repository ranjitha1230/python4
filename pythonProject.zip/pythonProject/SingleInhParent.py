class Animal:
    name = ""

    def eat(self):
        print("i can eat")


class Dog(Animal):
    def display(self):
        print("My name is", self.name)


beagle = Dog()
# data from parent class
beagle.name = "Elly"
beagle.eat()
# data from child class
beagle.display()
