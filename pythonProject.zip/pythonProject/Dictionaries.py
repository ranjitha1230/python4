

thisdict = {

    "brand":    "Ford",
    "model":    "Mustang",
    "year":     1964
}
print(thisdict["year"])


# get() -

thisdict = {

    "brand":    "Ford",
    "model":    "Mustang",
    "year":     1964
}
print(thisdict.get("model"))

# keys()

thisdict = {

    "brand":    "Ford",
    "model":    "Mustang",
    "year":     1964
}

x = thisdict.keys()
print(x) # before the change

thisdict["color"] = "white"

print(x) # after the change
print(thisdict)
