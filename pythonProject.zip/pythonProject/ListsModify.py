# access a particular element in the list
thislist = ["apple","banana","cherry", "orange", "pomo"]
print(thislist[1])
print(thislist[1:4])
print(thislist[:3])
print(thislist[2:])

# changing the list values - single item
thislist = ["apple","banana","cherry", "orange", "pomo"]
thislist[1] = "guava"
print(thislist)

# changing the list values - range of  item
thislist = ["apple","banana","cherry", "orange", "pomo"]
thislist[1:3] = ["guava", "kiwi", "papaya"]
print(thislist)

# insert elements
#append() - at the end of the list the item is added
# insert() - at specified index
#thislist.index(1,"orange")


# append
thislist = ["apple","banana","cherry", "orange", "pomo"]
thislist.append("kiwi")
print(thislist)


# insert

thislist = ["apple","banana","cherry", "orange", "pomo"]
thislist.insert(3, "kiwi")
print(thislist)

# remove method - to remove the items from the list
thislist = ["apple","banana","cherry", "orange", "pomo", "apple"]
thislist.remove("apple")
print(thislist)

# pop () remove at a specified index
thislist = ["apple","banana","cherry", "orange", "pomo", "apple"]
thislist.pop(1)
print(thislist)

thislist = ["apple","banana","cherry", "orange", "pomo", "apple"]
del thislist[1:3]
print(thislist)


thislist = ["apple","banana","cherry", "orange", "pomo", "apple"]
del thislist
print(thislist)












