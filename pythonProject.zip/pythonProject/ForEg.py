# break

thislist = ["apple","banana","cherry", "orange", "pomo"]
for x in thislist:
    print(x)
    if x == "banana":
        break

# contniue
thislist = ["apple", "banana", "cherry", "orange", "pomo"]
for x in thislist:
    if x == "banana":
        continue
    print(x)

# range
for x in range(6):
    print(x)

for x in range(1 , 10 , 2):
    print(x)

# pass
for x in ["apple", "banana", "cherry", "orange", "pomo"]:
    pass




