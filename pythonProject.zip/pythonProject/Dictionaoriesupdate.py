thisdict = {
    "brand":    "Ford",
    "model":    "Mustang",
    "year":     1964
}

# change the values

thisdict["model"] = "nissan"
print(thisdict)

# update()
thisdict.update({"year": 2023})
print(thisdict)

# remove item from the dictionary - pop()

thisdict.pop("model")
print(thisdict)


thisdict = {
    "brand":    "Ford",
    "model":    "Mustang",
    "year":     1964
}

# for loop
for x in thisdict:
    print(thisdict[x])

# copying - copy , dict()

thisdict = {
    "brand":    "Ford",
    "model":    "Mustang",
    "year":     1964
}

mydict = thisdict.copy()
print(mydict)