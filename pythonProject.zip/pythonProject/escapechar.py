#txt = "We are the so-called "Vikings" from the north.“
#print(txt)

txt = "We are the so-called \"Vikings\" from the north."
print(txt)
