x = 9
y = 67.89
z = 1j

print(type(x))
print(y)
print(z)

# convert x to float

x = float(x)
print(x)

# convert y to complex

b = complex(y)
print(b)
