class MyClass:
    empID = 7888
    empName = "Ravi"
    empBU = "HR"
    empSal = 7899990

    def func(self):
        print("The emp details")


obj1 = MyClass()
print(obj1.empSal)
print(obj1.empBU)
print(obj1.empName)
print(obj1.empID)
obj1.func()



