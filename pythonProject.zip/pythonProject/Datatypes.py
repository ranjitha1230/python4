#integers
x = 9
y = 67.89
z = 1j

#float
print(type(x))
print(y)
print(z)

# convert x to float

x = float(x)
print(x)

# convert y to complex
# complex
b = complex(y)
print(b)


# strings
x = 'hello world'
print(x)


# collection of values / elements
# list - square brace -list
x = ["x", "y", "z"]
print(x)

# set - curly brace is a set
x = {"x", "y", "z"}
print(x)


# tuple - normal  brace is a set
x = ("x", "y", "z")
print(x)

# dictionary - key and value

dict = {
    "brand": "Ford",
    "model": "2023 model",
    "year": "2023"
}

print(dict)

# boolean

print(10>8)
print(10==9)
print(10<9)


# binary data types
# byte

x = b"hello"
print(type(x))

#memory view

x = memoryview(bytes(5))
print(x)

# none

x = None
print(x)
