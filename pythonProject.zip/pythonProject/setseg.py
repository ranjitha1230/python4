
# sets are unchangeabale , unordered and do not allow dupliactes


thisset = {"apple","banana","cherry", "orange", "pomo", "chiku" , "chiku"}
print(thisset)



thisset = {"apple","banana","cherry", "orange", "pomo", "chiku" , "chiku"}
for i in thisset:
    print(i)


# banana is present
thisset = {"apple","banana","cherry", "orange", "pomo", "chiku" , "chiku"}
print ("banana" in thisset)

# change items
#once set is created you cannot chnage the items in the set , you can add and remove items

thisset = {"apple","banana","cherry", "orange", "pomo", "chiku" , "chiku"}
thisset.add("kiwi")
print(thisset)

# update method - to add another set in to the current set - update()
thisset = {"apple","banana","cherry", "orange"}
newset = {"kiwi" , "pomo"}
thisset.update(newset)
print(thisset)

#remove() and discard() - remove the particular element what we are giving.
# pop() - random remove of the item
# union method - join the sets

#remove - will raise a error if the item to remove is not present
#discard -will not  raise a error if the item to remove is not present

set1 = {"a", "b ", "c"}
set2 = {1, 2 ,3}

set1 =set1.union(set2)
print(set1)








