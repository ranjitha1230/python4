# Single commenting
# This is a selenium training program
# This is wriiten in python languauge
# written by @harsha

"""
Multi commenting
This is a selenium training program
This is wriiten in python languauge
written by @harsha
"""

print("selenium training")