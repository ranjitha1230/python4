# check if the item exists
thislist = ["apple","banana","cherry", "orange", "pomo"]
if "toy" in thislist:
    print("yes the item is in the list")
else:
    print("no the item is not present in the list")

# check if not  the item exists
thislist = ["apple","banana","cherry", "orange", "pomo"]
if "toy" in thislist:
    print("yes the item is in the list")
if "cherry" in thislist:
    print("yes the item is in the list")
else:
    print("no the item is not present in the list")

#for loop ofr accessing the list items

thislist = ["apple","banana","cherry", "orange", "pomo"]
for x in thislist:
    print(x)

#range() and len()

thislist = ["apple","banana","cherry", "orange", "pomo"]
for x in range(len(thislist)):
    print(thislist[x])

#sorting - alphanumeric and ascending default
thislist = ["banana", "orange", "cherry","pomo" ,"apple"]
thislist.sort()
print(thislist)

thislist = [89, 78, 12,9 ,50]
thislist.sort(reverse = True)
print(thislist)

#copy ()
thislist = ["banana", "orange", "cherry","pomo" ,"apple"]
mylist = thislist.copy()
print(mylist)

#join()
list1 = ["banana", "orange", "cherry"]
list2 = ["pomo" ,"apple"]
list3 = list1 + list2
list3.sort()
print(list3)







