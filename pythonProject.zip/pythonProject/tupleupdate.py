# updating the existing tuple
thistuple = ("apple","banana","cherry", "orange", "pomo")
list1 = list(thistuple)
list1[1] = "kiwi"
newtuple = tuple(list1)
print(newtuple)

# add items to tuple
thistuple = ("apple","banana","cherry", "orange", "pomo")
list1 = list(thistuple)
list1.append("chiku")
newtuple = tuple(list1)
print(newtuple)

# remove the items from the tuple

thistuple = ("apple","banana","cherry", "orange", "pomo", "chiku")
list1 = list(thistuple)
list1.remove("chiku")
newtuple = tuple(list1)
print(newtuple)

# unpacking - allow to extract the values back into the variables

thistuple = ("apple","banana","cherry", "orange", "pomo", "chiku")
(a,b,c,d,e,f) = thistuple
print(a)
print(b)
print(c)
print(d)
print(e)
print(f)


