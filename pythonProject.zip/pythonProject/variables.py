# single value assigning
x = 6
y = "Ravi"

print(x)
print(y)

# multiple value assigning with same data types

x,y,z = 1,2,3
print(x)
print(y)
print(z)

# multiple value assigning with different  data types

# type function can be used for fetching the data type of the variable declared

x,y,z = 1 ,2 ,"Raj"

print(type(x))
print(type(y))
print(type(z))

# rules for creating variables

# cannot start a variable with digits
# cannot start a variable with special characters $,%&*@ - except - _ - underscore

# can write  a variable starting with _ and alphabets

_a = 6
bngn = "hello"
v234 = 9
v_ = 90

# variables are case sensitive

age = "23"
Age = "26"
AGE = "27"

print(age)
print(AGE)
print(Age)





