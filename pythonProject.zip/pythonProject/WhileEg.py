# initialization
# increment
# break will stop the exeution of the loop even if the while statement is true

i =1
while i <= 10:
    print(i)
    if i == 6:
        break
    i += 1

# continue

i =0
while i < 10:
    i += 1
    if i == 6:
        continue
    print(i)




#decrement

i = 10
while i>=1:
    print(i)
    i -= 1