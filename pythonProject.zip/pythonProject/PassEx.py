# pass statement ignores the error or execution of the step

a = 10
b = 500

if b>a:
    pass
else:
    print("a is smaller than b ")
